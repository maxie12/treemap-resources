/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filterDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author msondag
 */
public class GeneratedRating {

    public static GeneratedRating mergeRating(List<GeneratedRating> generatedRatings) {
        String label = generatedRatings.get(0).label;
        String parent = generatedRatings.get(0).parent;
        List<Integer> newRatings = new ArrayList();
        //initialize to 0
        for (int i = 0; i < generatedRatings.get(0).ratings.size(); i++) {
            newRatings.add(0);
        }
        //sum the values
        for (GeneratedRating gr : generatedRatings) {
            for (int i = 0; i < gr.ratings.size(); i++) {
                newRatings.set(i, newRatings.get(i) + gr.ratings.get(i));
            }
        }
        return new GeneratedRating(label, parent, newRatings);
    }

    public String label;
    public String parent;
    public List<Integer> ratings;

    public GeneratedRating(String label, List<Integer> ratings) {
        this.label = label;
        this.ratings = ratings;
        parent = "root";
    }

    public GeneratedRating(String label, String parent, List<Integer> ratings) {
        this.label = label;
        this.parent = parent;
        this.ratings = ratings;
    }

    public GeneratedRating(String label, String parent, HashMap<Integer, Integer> sumValues) {
        List<Integer> ratings = new ArrayList();
        for (int i = 0; i < sumValues.size(); i++) {
            ratings.add(sumValues.get(i));
        }

        this.label = label;
        this.parent = parent;
        this.ratings = ratings;
    }

    @Override
    public String toString() {

        if (ratings.size() == 0) {
            return null;
        }
        String returnString = label + "," + parent + ",";
        for (int i = 0; i < ratings.size() - 1; i++) {
            returnString += ratings.get(i) + ",";
        }
        returnString += ratings.get(ratings.size() - 1);
        return returnString;
    }
}
