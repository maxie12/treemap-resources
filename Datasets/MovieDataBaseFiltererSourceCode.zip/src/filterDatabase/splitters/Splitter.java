/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filterDatabase.splitters;

import filterDatabase.GeneratedRating;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import moviedatabase.DataSetSetting;
import moviedatabase.datastructures.MovieDataBase;
import moviedatabase.datastructures.Movie;

/**
 * Splits the data recursively into subclasses
 *
 * @author msondag
 */
public abstract class Splitter {

    /**
     * The splitters to go into after processing this one
     */
    protected Splitter recursiveSplit;

    protected List<MovieDataBase> splitDataBases = new ArrayList();

    public boolean filterEnabled = false;

    public String label = "";
    public String parentLabel = "";

    protected boolean isRoot = false;

    /**
     * Whether this splitter adds a new level to the dataset, or is a
     * combination splitter
     */
    protected boolean newLevel;

    /**
     * Splits the data according to the specifics of the splitter
     *
     * @param db
     */
    protected abstract void splitData(MovieDataBase db);

    public void setSplitter(Splitter s) {
        recursiveSplit = s;
    }

    public List<GeneratedRating> getOutput(MovieDataBase db, DataSetSetting setting) {

        List<GeneratedRating> generatedRatings = new ArrayList();

        //split the data according to the splitter
        splitData(db);

        verifyDataBaseDisjoint(db);
        //TODO: bug, last level values are not taken into account
        if (recursiveSplit == null) {
            //at the lowest level split, so we can add the actual output
            for (MovieDataBase dbSplit : splitDataBases) {
                for (Movie m : dbSplit.movies.values()) {
                    GeneratedRating gr = m.getRatingOutput(setting, parentLabel);

                    if (gr == null) {
                        //did not have enough values in it to be put into the output
                        //or did not have enough sum
                        continue;
                    }
                    generatedRatings.add(gr);
                }
            }
        } else {
            for (int i = 0; i < splitDataBases.size(); i++) {
                MovieDataBase mdb = splitDataBases.get(i);
                //recursively build the output string
                //need a unique label for every split
                recursiveSplit.label = this.label + "//split" + i;
                recursiveSplit.parentLabel = this.label;
                List<GeneratedRating> mdbOutput = recursiveSplit.getOutput(mdb, setting);
                //add the output
                generatedRatings.addAll(mdbOutput);
            }

            verifyRatings(generatedRatings);

            //every child that is not a leaf has the same label, we need to merge these values together
            generatedRatings = mergeRatings(generatedRatings);

            verifyRatings(generatedRatings);

            HashMap<Integer, Integer> sumValues = new HashMap();
            //get the sum of ratings for the parent
            for (GeneratedRating gr : generatedRatings) {
                for (int index = 0; index < gr.ratings.size(); index++) {
                    if (gr.parent.equals(this.label)) {
                        int value = gr.ratings.get(index);
                        if (!sumValues.containsKey(index)) {
                            sumValues.put(index, value);//add it to the hashmap
                        } else {
                            sumValues.put(index, sumValues.get(index) + value);//increase hashmap value
                        }
                    }
                }
            }

            //add the parent
            if (!sumValues.isEmpty()) {
                GeneratedRating gr = new GeneratedRating(label, parentLabel, sumValues);
                generatedRatings.add(gr);
            }
        }

        //clean up manually. Required since we are reusing the splitters
        splitDataBases = new ArrayList();

        verifyRatings(generatedRatings);

        return generatedRatings;
    }

    protected void verifyDataBaseDisjoint(MovieDataBase originalDb) {
        List<Integer> movies = new ArrayList();
        for (MovieDataBase db : splitDataBases) {
            for (Integer movieId : db.movies.keySet()) {
                if (movies.contains(movieId)) {
                    System.err.println("Not disjoint");
                    return;
                }
                movies.add(movieId);
            }
        }
    }

    private List<GeneratedRating> mergeRatings(List<GeneratedRating> mdbOutput) {
        List<GeneratedRating> children = new ArrayList();
        for (GeneratedRating gr : mdbOutput) {
            if (gr.parent.equals(this.label)) {
                children.add(gr);
            }
        }
        //merge all children with duplicate labels
        HashMap<String, List<GeneratedRating>> hm = new HashMap();
        for (GeneratedRating child : children) {
            if (!hm.containsKey(child.label)) {
                hm.put(child.label, new ArrayList());
            }
            hm.get(child.label).add(child);
        }
        //hashmap now contains all duplicate children, remains to merge them
        for (String label : hm.keySet()) {
            GeneratedRating gr = GeneratedRating.mergeRating(hm.get(label));
            mdbOutput.removeAll(hm.get(label));
            mdbOutput.add(gr);
        }
        return mdbOutput;
    }

    private void verifyRatings(List<GeneratedRating> generatedRatings) {
        HashSet<String> labelList = new HashSet();
        for (GeneratedRating gr : generatedRatings) {
            if (labelList.contains(gr)) {
                System.err.println("Duplicate label");
                return;
            }
        }

    }
}
