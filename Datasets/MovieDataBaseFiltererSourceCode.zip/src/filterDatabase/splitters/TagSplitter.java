/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filterDatabase.splitters;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import moviedatabase.datastructures.MovieDataBase;
import moviedatabase.datastructures.Genre;
import moviedatabase.datastructures.Movie;
import moviedatabase.datastructures.Rating;
import moviedatabase.datastructures.Tag;
import moviedatabase.datastructures.User;

/**
 *
 * @author msondag
 */
public class TagSplitter extends Splitter {

    List<String> tags;

    public TagSplitter(List<String> tags) {
        this.tags = new ArrayList();
        if (tags != null) {
            this.tags.addAll(tags);
        }
    }

    @Override
    protected void splitData(MovieDataBase db) {
        List<Movie> unfilteredMovies = new ArrayList();
        unfilteredMovies.addAll(db.movies.values());

        List<Movie> moviedParsed = new ArrayList();

        for (String s : tags) {
            //A movie goes in if it is in 1 tag but non of the others.
            List<String> otherTags = new ArrayList(tags);
            otherTags.remove(s);

            List<Movie> filterMovies = new ArrayList();
            for (Movie m : db.movies.values()) {
                if (m.containsTag(s)) {
                    //contains the current tag, have to check if it does not contain the other genres
                    boolean hasOtherTag = false;
                    for (String otherS : otherTags) {
                        if (m.containsTag(otherS)) {
                            hasOtherTag = true;
                            break;
                        }
                    }
                    if (!hasOtherTag) {
                        filterMovies.add(m);
                    }
                }
            }
            if (!filterMovies.isEmpty()) {
                MovieDataBase dbCopy = db.copy();
                dbCopy.filterMovies(filterMovies);
                splitDataBases.add(dbCopy);

                unfilteredMovies.removeAll(filterMovies);
                moviedParsed.addAll(filterMovies);
            }
        }

        verifyDataBaseDisjoint(db);

        if ((moviedParsed.size() + unfilteredMovies.size()) != db.movies.size()) {
            System.err.println("off error");
        }
        if (!filterEnabled) {
            MovieDataBase dbCopy = db.copy();
            dbCopy.filterMovies(unfilteredMovies);
            splitDataBases.add(dbCopy);
        }
        verifyDataBaseDisjoint(db);

    }

}
