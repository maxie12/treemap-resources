/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filterDatabase.splitters;

import java.util.ArrayList;
import java.util.List;
import moviedatabase.datastructures.MovieDataBase;
import moviedatabase.datastructures.Genre;
import moviedatabase.datastructures.Movie;

/**
 *
 * @author msondag
 */
public class GenreSplitter extends Splitter {

    List<Genre> genres;

    public GenreSplitter(List<Genre> genres) {
        this.genres = new ArrayList();
        if (genres != null) {
            this.genres.addAll(genres);
        }
        
    }

    
    
    @Override
    protected void splitData(MovieDataBase db) {
        List<Movie> unfilteredMovies = new ArrayList();
        unfilteredMovies.addAll(db.movies.values());

        for (Genre g : genres) {
            //A movie goes in if it is in 1 genre but non of the others.
            List<Genre> otherGenres = new ArrayList(genres);
            otherGenres.remove(g);

            List<Movie> filterMovies = new ArrayList();
            for (Movie m : db.movies.values()) {
                if (m.genres.contains(g)) {
                    //contains the current genre, have to check if it does not contain the other genres
                    boolean hasOtherGenre = false;
                    for (Genre otherG : otherGenres) {
                        if (m.genres.contains(otherG)) {
                            hasOtherGenre = true;
                            break;
                        }
                    }
                    if (!hasOtherGenre) {
                        filterMovies.add(m);
                    }
                }
            }
            if (!filterMovies.isEmpty()) {
                MovieDataBase dbCopy = db.copy();
                dbCopy.filterMovies(filterMovies);

                splitDataBases.add(dbCopy);
                unfilteredMovies.removeAll(filterMovies);
            }
        }
        if (!filterEnabled) {
            MovieDataBase dbCopy = db.copy();
            dbCopy.filterMovies(unfilteredMovies);
            splitDataBases.add(dbCopy);
        }
    }

}
