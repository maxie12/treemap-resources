/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filterDatabase.splitters;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import moviedatabase.datastructures.Genre;
import moviedatabase.datastructures.MovieDataBase;
import moviedatabase.datastructures.Movie;
import moviedatabase.datastructures.Rating;
import moviedatabase.datastructures.Tag;
import moviedatabase.datastructures.User;

/**
 * Splits based on substring the title contains
 *
 * @author msondag
 */
public class TitleSplitter extends Splitter {

    List<String> titles;

    public TitleSplitter( List<String> titles) {
        this.titles = new ArrayList();
        if (titles != null) {
            this.titles.addAll(titles);
        }

        
    }

    
    
    @Override
    protected void splitData(MovieDataBase db) {
        List<Movie> unfilteredMovies = new ArrayList();
        unfilteredMovies.addAll(db.movies.values());

        for (String title : titles) {
            //A movie goes in if it is in 1 genre but non of the others.
            List<String> otherGenres = new ArrayList(titles);
            otherGenres.remove(title);

            List<Movie> filterMovies = new ArrayList();
            for (Movie m : db.movies.values()) {
                if (m.title.contains(title)) {
                    //contains the current genre, have to check if it does not contain the other genres
                    boolean hasOtherTitle = false;
                    for (String otherTitle : otherGenres) {
                        if (m.title.contains(otherTitle)) {
                            hasOtherTitle = true;
                            break;
                        }
                    }
                    if (!hasOtherTitle) {
                        filterMovies.add(m);
                    }
                }
            }
            if (!filterMovies.isEmpty()) {
                MovieDataBase dbCopy = db.copy();
                dbCopy.filterMovies(filterMovies);

                splitDataBases.add(dbCopy);
                unfilteredMovies.removeAll(filterMovies);
            }
        }
        if (!filterEnabled) {
            MovieDataBase dbCopy = db.copy();
            dbCopy.filterMovies(unfilteredMovies);
            splitDataBases.add(dbCopy);
        }
    }

}
