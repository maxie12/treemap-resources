/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filterDatabase.splitters;

import java.util.ArrayList;
import java.util.List;
import moviedatabase.datastructures.Movie;
import moviedatabase.datastructures.MovieDataBase;

/**
 *
 * @author msondag
 */
public class YearSplitter extends Splitter {

    public int year;

    public YearSplitter(int year) {
        this.year = year;
    }

    
    
    @Override
    protected void splitData(MovieDataBase db) {

        List<Movie> filterMoviesBefore = new ArrayList();
        List<Movie> filterMoviesAfter = new ArrayList();
        for (Movie m : db.movies.values()) {
            if (m.year < 0) {
                //error in year
                continue;
            } else if (m.year <= year) {
                filterMoviesBefore.add(m);
            } else {
                filterMoviesAfter.add(m);
            }
        }

        if (!filterMoviesBefore.isEmpty()) {
            MovieDataBase dbCopyBefore = db.copy();
            dbCopyBefore.filterMovies(filterMoviesBefore);
            splitDataBases.add(dbCopyBefore);
        }
        verifyDataBaseDisjoint(db);
        
        if (!filterMoviesAfter.isEmpty()) {
            MovieDataBase dbCopyAfter = db.copy();
            dbCopyAfter.filterMovies(filterMoviesAfter);
            splitDataBases.add(dbCopyAfter);
        }
        verifyDataBaseDisjoint(db);
//        System.out.println("yearSplit");
        
    }

}
