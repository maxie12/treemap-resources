/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filterDatabase;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import moviedatabase.datastructures.Movie;
import moviedatabase.datastructures.MovieDataBase;

/**
 *
 * @author msondag
 */
public class DataSetWriter {

    public void writeDataset(String outputFileName, List<GeneratedRating> ratings) {

//        //merges duplicate ratings together
//        mergeRatings(ratings);
        if (ratings.size() > 1500 || ratings.size() < 15) {
            //don't want the truly large datasets, to slow to calculate
            System.out.println("amount of ratings to large/small: = " + ratings.size());
            return;
        }
        if (ratings.get(0).ratings.size() < 5 || ratings.get(0).ratings.size() > 500) {
            System.out.println("length of rtings to long/tiny: " + ratings.get(0).ratings.size());
            return;
        }

        File outputFile = new File(outputFileName);
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(outputFile));

            for (GeneratedRating rating : ratings) {
                String line = rating.toString();
                if (line != null) {
                    writer.write(line + "\r\n");
                }
            }
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(DataSetWriter.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                writer.close();
            } catch (IOException ex) {
                Logger.getLogger(DataSetWriter.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }


}
