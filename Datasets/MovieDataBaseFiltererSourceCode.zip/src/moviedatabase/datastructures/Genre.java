/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviedatabase.datastructures;

import java.util.ArrayList;
import java.util.List;

/**
 * Genre has a fixed amount of categories
 *
 * @author msondag
 */
public enum Genre {

    ACTION, ADVENTURE, ANIMATION, CHILDREN, COMEDY, CRIME, DOCUMENTARY, DRAMA, FANTASY,
    FILMNOIR, HORROR, MUSICAL, MYSTERY, ROMANCE, SCIFI, THRILLER, WAR, WESTERN, NONE;

    public static Genre convertString(String g) {
        if ("Action".equals(g)) {
            return Genre.ACTION;
        }
        if ("Adventure".equals(g)) {
            return Genre.ADVENTURE;
        }
        if ("Animation".equals(g)) {
            return Genre.ANIMATION;
        }
        if ("Children's".equals(g)) {
            return Genre.CHILDREN;
        }
        if ("Comedy".equals(g)) {
            return Genre.COMEDY;
        }
        if ("Crime".equals(g)) {
            return Genre.CRIME;
        }
        if ("Documentary".equals(g)) {
            return Genre.DOCUMENTARY;
        }
        if ("Drama".equals(g)) {
            return Genre.DRAMA;
        }
        if ("Fantasy".equals(g)) {
            return Genre.FANTASY;
        }
        if ("Film-Noir".equals(g)) {
            return Genre.FILMNOIR;
        }
        if ("Horror".equals(g)) {
            return Genre.HORROR;
        }
        if ("Musical".equals(g)) {
            return Genre.MUSICAL;
        }
        if ("Mystery".equals(g)) {
            return Genre.MYSTERY;
        }
        if ("Romance".equals(g)) {
            return Genre.ROMANCE;
        }
        if ("Sci-Fi".equals(g)) {
            return Genre.SCIFI;
        }
        if ("Thriller".equals(g)) {
            return Genre.THRILLER;
        }
        if ("War".equals(g)) {
            return Genre.WAR;
        }
        if ("Wester".equals(g)) {
            return Genre.WESTERN;
        }
        if ("(no genres listed)".equals(g)) {
            return Genre.NONE;
        }
        return null;
    }

    public static List<Genre> convertStrings(String genres) {
        List<Genre> genreList = new ArrayList();

        for (String s : genres.split("\\|")) {
            Genre g = Genre.convertString(s);
            genreList.add(g);
        }
        return genreList;

    }

}
