/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviedatabase.datastructures;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author msondag
 */
public class User {
    
    int userId;

    public User(int userId){
        this.userId = userId;
    }
    
}
