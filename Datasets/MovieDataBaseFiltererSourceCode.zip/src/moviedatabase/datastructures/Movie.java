/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviedatabase.datastructures;

import filterDatabase.GeneratedRating;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import moviedatabase.DataSetSetting;

/**
 *
 * @author msondag
 */
public class Movie {

    public int movieId;
    public String title;
    public List<Genre> genres;
    public List<Rating> ratings = new ArrayList();
    public List<Tag> tags = new ArrayList();
    public int year;

    //TODO Figure out if tag genome is usefll
    public Movie(int movieId, String title, List<Genre> genres) {
        this.movieId = movieId;
        this.title = title;
        this.genres = genres;

        this.year = -9999;
        //horribly inefficent, but oh well
        for (int i = 0; i < title.length() - 4; i++) {
            String possibleYear = title.substring(title.length() - i - 4, title.length() - i);
            int year = -9999;
            try {
                year = Integer.parseInt(possibleYear);
            } catch (NumberFormatException ex) {
                year = -9999;
            }
            if (year != -9999) {
                this.year = year;
                break;
                //break out of the loop with the correct year as soon as we found one
            }
        }

        //debugging if we missed any
        if (this.year == -9999) {
            System.out.println("error parsing");
            System.out.println("title = " + title);
        }
    }

    public void addRating(Rating r) {
        ratings.add(r);
    }

    public void addTag(Tag t) {
        tags.add(t);
    }

    /**
     * returns the movie alongs with its amount of ratings at each
     * interval
     *
     * @param interval
     * @param additive
     * @return
     */
    public GeneratedRating getRatingOutput(DataSetSetting setting, String parent) {
        int intervalAmount = getIntervalAmount(setting);
        HashMap<Integer, Integer> ratingAmount = new HashMap();
        for (int i = 0; i <= (intervalAmount + 1); i++) {
            ratingAmount.put(i, 0);
        }

        for (Rating r : ratings) {

//            if (r.timestamp < setting.startTime || r.timestamp > setting.endTime) {
//                continue;
//            }
            if (r.timestamp > setting.endTime) {
                continue;
            }
            if (r.timestamp < setting.startTime && setting.additive == false) {
                //additive we add all values
                continue;
            }
            int intervalCount = getIntervalCount(setting, r.timestamp);
            if (intervalCount < 0) {
                intervalCount = 0;
            }
            ratingAmount.put(intervalCount, ratingAmount.get(intervalCount) + 1);
        }
//        System.out.println("intervalAmount = " + intervalAmount);
//        //set values below minvalue to 0
//        for (int i = 0; i < (intervalAmount + 1); i++) {
//            if (ratingAmount.get(i) < setting.minValue) {
//                ratingAmount.put(i, 0);
//            }
//        }
        //get the count and sum of values
        int count = 0;
        int sum = 0;
        for (int i = 0; i < (intervalAmount + 1); i++) {
            if (ratingAmount.get(i) > 0) {
                count++;
                sum += ratingAmount.get(i);
            }
        }
        //return if there are not enough values
        if (count < setting.minimumNonZeroValues) {
//            if (r.nextInt(5000) == 1) {
//                System.out.println("filterNonZero");
//            }
            // not enough values
            return null;
        }
        if (sum < setting.minTotalValue) {
//            if (r.nextInt(5000) == 1) {
//                System.out.println("filterMinTotal");
//            }
            return null;
        }

        sum = 0;
        List<Integer> ratingNumbers = new ArrayList();
        for (int i = 0; i < (intervalAmount - 1); i++) {
            if (setting.additive) {
                sum += ratingAmount.get(i);
                ratingNumbers.add(sum);
            } else {
                ratingNumbers.add(ratingAmount.get(i));
            }
        }
        GeneratedRating gr = new GeneratedRating(parent + "//" + movieId, parent, ratingNumbers);
        return gr;
    }

    private int getIntervalAmount(DataSetSetting setting) {
        long startTime = setting.startTime;
        long endTime = setting.endTime;
        long interval = setting.interval;
        return (int) (Math.ceil((endTime - startTime) / interval));
    }

    private int getIntervalCount(DataSetSetting setting, long timeStamp) {
        long startTime = setting.startTime;
        long interval = setting.interval;

        return (int) (Math.ceil((timeStamp - startTime) / interval));
    }

    public boolean containsTag(String s) {
        for (Tag t : tags) {
            if (t.tag.toLowerCase().contains(s.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

}
