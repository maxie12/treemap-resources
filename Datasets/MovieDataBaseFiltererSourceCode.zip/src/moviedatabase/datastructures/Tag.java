/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviedatabase.datastructures;

/**
 *
 * @author msondag
 */
public class Tag {

    public Movie movie;
    public User user;//tagged by this user
    public String tag;
    public long timestamp;

    public Tag(Movie m, User u, String tag, long timestamp) {
        this.movie = m;
        this.user = u;
        this.tag = tag;
        this.timestamp = timestamp;
    }
}
