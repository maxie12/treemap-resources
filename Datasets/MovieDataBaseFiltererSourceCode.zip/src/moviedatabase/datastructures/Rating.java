/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviedatabase.datastructures;

/**
 * A rating of an user to a move
 *
 * @author msondag
 */
public class Rating {

    public Movie movie;
    public User user;
    public double rating;
    public long timestamp;

    public Rating(Movie movie, User user, double rating, long timestamp) {
        this.movie = movie;
        this.user = user;
        this.rating = rating;
        this.timestamp = timestamp;
        
        movie.addRating(this);
    }

}
