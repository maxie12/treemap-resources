/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviedatabase.datastructures;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/**
 *
 * @author msondag
 */
public class MovieDataBase {

    //mapping from movieIds to movies
    public HashMap<Integer, Movie> movies = new HashMap();
    //mapping from userIds to users
    public HashMap<Integer, User> users = new HashMap();

    public ArrayList<Rating> ratings = new ArrayList();
    public ArrayList<Tag> tags = new ArrayList();

    public MovieDataBase(HashMap<Integer, Movie> movies, HashMap<Integer, User> users, ArrayList<Rating> ratings, ArrayList<Tag> tags) {
        this.movies = new HashMap(movies);
        this.users = new HashMap(users);
        this.ratings = new ArrayList(ratings);
        this.tags = new ArrayList(tags);
    }

    public MovieDataBase(HashMap<Integer, Movie> movies, HashMap<Integer, User> users, ArrayList<Rating> ratings, ArrayList<Tag> tags, boolean noCopy) {
        this.movies = movies;
        this.users = users;
        this.ratings = ratings;
        this.tags = tags;
    }

    public MovieDataBase copy() {
//        return new MovieDataBase(movies, users, ratings, tags);
        return new MovieDataBase(movies, new HashMap(), new ArrayList(), new ArrayList());
    }

    /**
     * Remove the movie from
     *
     * @param m
     */
    public void filterMovies(List<Movie> movies) {
//        System.out.println("filering movies");
        //remove from movies
        this.movies = new HashMap();
        for (Movie m : movies) {
//            if (m.year < 1993 || m.year > 2000) {
            this.movies.put(m.movieId, m);
//            }
        }

        //TODO: Not needed for now
//        System.out.println("filtering tags");
//        //remove tags with this movie
//        List<Tag> tagsToRemove = new ArrayList();
//        for (Tag t : tags) {
//            if (movies.contains(t.movie)) {
//                tagsToRemove.add(t);
//            }
//        }
//        tags.removeAll(tagsToRemove);
//        System.out.println("filtering ratings");
//        //remove ratings involving the movies from users
//        List<Rating> ratingsToRemove = new ArrayList();
//        for (Movie m : movies) {
//            ratingsToRemove.addAll(m.ratings);
//        }
//        ratings.removeAll(ratingsToRemove);
//        System.out.println("done filtering");
    }
}
