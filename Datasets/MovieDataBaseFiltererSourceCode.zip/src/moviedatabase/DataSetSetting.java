/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviedatabase;

import filterDatabase.splitters.GenreSplitter;
import filterDatabase.splitters.Splitter;
import filterDatabase.splitters.TagSplitter;
import filterDatabase.splitters.TitleSplitter;
import filterDatabase.splitters.YearSplitter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import moviedatabase.datastructures.Genre;

/**
 *
 * @author msondag
 */
public class DataSetSetting {

//    private final long startTime = 789652004;
//    private final long endTime = 1427784002;
    public String fileIdentifier;
    public Splitter root;

    public long startTime;
    public long endTime;
    public long interval;
    public boolean additive;

    public int minimumNonZeroValues;
    public int minTotalValue;
    public int minValue;

    public DataSetSetting(Splitter root, long startTime, long endTime, long interval, boolean additive, int minimumNonZeroValues, String fileIdentifier, int minTotalValue, int minValue) {
        this.root = root;
        this.startTime = startTime;
        this.endTime = endTime;
        this.interval = interval;
        this.additive = additive;
        this.fileIdentifier = fileIdentifier;
        this.minimumNonZeroValues = minimumNonZeroValues;
        this.minTotalValue = minTotalValue;
        this.minValue = minValue;
    }

    public static List<DataSetSetting> finalSettings() {
        List<DataSetSetting> settings = new ArrayList();
        settings.addAll(aaRating());
        settings.addAll(addAARating());
        settings.addAll(biMonthly18Rating());
        settings.addAll(dialy9MonthsAARating());
        settings.addAll(quarterAddRating());
        settings.addAll(quarterRating());
        settings.addAll(WeeklyAddRating());
        settings.addAll(aaAddSmallRating());
        return settings;
    }

    public static List<DataSetSetting> finalSettings2() {
        List<DataSetSetting> settings = new ArrayList();
        settings.addAll(aaRating2());
        settings.addAll(addAARating2());
        settings.addAll(biMonthly18Rating2());
        settings.addAll(dialy9MonthsAARating2());
        settings.addAll(quarterAddRating2());
        settings.addAll(quarterRating2());
        settings.addAll(WeeklyAddRating2());
        settings.addAll(aaAddSmallRating2());
        return settings;
    }

    public static List<DataSetSetting> setting2() {

        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1289652004;
//        long endTime =    1427784002;
//        int minValue = 1;
//        int minTotalValue = 100;
        for (int x = 0; x < Genre.values().length; x++) {
            Genre g1 = Genre.values()[x];
            for (int y = x + 1; y < Genre.values().length; y++) {
                Genre g2 = Genre.values()[y];
                ArrayList<Genre> genreList = new ArrayList();
                genreList.add(g1);
                genreList.add(g2);
                for (int minTotalValue = 20; minTotalValue <= 200; minTotalValue *= 2) {

                    for (int minValue = 1; minValue <= 200; minValue *= 2) {
                        for (int minimumNonZeroValues = 1; minimumNonZeroValues <= 500; minimumNonZeroValues *= 2) {
                            for (int i = 60; i <= 24 * 365; i = i * 2) {
                                long interval = 60 * 60 * i;
                                for (int bool = 0; bool <= 1; bool++) {
                                    boolean additive = (bool == 1);

                                    GenreSplitter s1 = new GenreSplitter(genreList);
                                    s1.label = "root//split";
                                    s1.parentLabel = "root";
                                    s1.filterEnabled = true;

                                    String identifier = "single" + i + g1.name() + g2.name() + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
                                    DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
                                    settings.add(setting);

                                }
                            }
                        }
                    }
                }
            }
        }
        System.out.println("settings.size() = " + settings.size());
        return settings;
    }
    //complete period of time
    //        long startTime = 789652004;
    //        long endTime = 1427784002;
    //Genres:
    //ACTION, ADVENTURE, ANIMATION, CHILDREN, COMEDY, CRIME, DOCUMENTARY, DRAMA, FANTASY,FILMNOIR, HORROR, MUSICAL, MYSTERY, ROMANCE, SCIFI, THRILLER, WAR, WESTERN, NONE;

    public static List<DataSetSetting> setting1() {

        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
        long startTime = 789652004;
        long endTime = 1427784002;
//        long endTime = 1425184000;
//        long startTime = 1153318400;

        //about 20 year of data in total
//        int minimumNonZeroValues = 30;
//        int minTotalValue = 30000;
        //no additive values
//        boolean additive = false;
        //make a large amount of datasets
        //select the genres
//            Genre g1 = Genre.ACTION;
//            Genre g2 = Genre.ROMANCE;
//            Genre g3 = Genre.ADVENTURE;
//        for (int x = 0; x < Genre.values().length; x++) {
//            Genre g1 = Genre.values()[x];
//                    genreList.add(g3);
        for (int i = 24 * 7; i <= 24 * 365; i = i * 2) {
//                long interval = 60 * 60 * i;
            long interval = 60 * 60 * i;
//                for (int y = x + 1; y < Genre.values().length; y++) {
//                    Genre g2 = Genre.values()[y];
//                    ArrayList<Genre> genreList = new ArrayList();
//                    genreList.add(g1);
//                    genreList.add(g2);

            for (int minimumNonZeroValues = 1; minimumNonZeroValues <= 24; minimumNonZeroValues *= 2) {

                //day long intervals
//        int i =1;
//        long interval = 60 * 60 * 24 * 365;//* i;
                //select the minTotalValue for filtering
                for (int minTotalValue = 1000; minTotalValue <= 10000; minTotalValue = minTotalValue * 4) {

                    for (int minValue = 100; minValue <= 10000; minValue = minValue * 4) {

                        //additive or not
                        for (int bool = 0; bool <= 1; bool++) {
                            boolean additive = (bool == 1);

                            ArrayList<Genre> genreList = new ArrayList();
                            genreList.add(Genre.CRIME);
                            genreList.add(Genre.ADVENTURE);
                            genreList.add(Genre.DRAMA);
                            GenreSplitter s1 = new GenreSplitter(genreList);
                            s1.label = "root//split";
                            s1.parentLabel = "root";
                            s1.filterEnabled = true;

                            YearSplitter s2 = new YearSplitter(2010);
                            s1.setSplitter(s2);

                            List<String> tags = new ArrayList();
                            tags.add("Ford");
                            tags.add("Pitt");
                            tags.add("Depp");
                            tags.add("Hanks");
                            tags.add("Stewart");
                            tags.add("Cooper");
                            tags.add("Grant");
                            tags.add("Flynn");
////                            
                            TagSplitter s3 = new TagSplitter(tags);
                            s3.filterEnabled = true;
                            s2.setSplitter(s3);

                            List<String> titles = new ArrayList();
                            titles.add("Act");
                            titles.add("War");
                            titles.add("Love");
                            titles.add("Time");
                            titles.add("Spirit");
                            titles.add("Night");
                            TitleSplitter s4 = new TitleSplitter(titles);
                            s3.setSplitter(s4);
//                                    s4.filterEnabled = true;

                            tags = new ArrayList();
                            tags.add("Friend");
                            tags.add("Enemy");

                            TagSplitter s5 = new TagSplitter(tags);
                            s5.label = "root//genSplit//yearSplit//titleSplit//split//split";
//                                    s5.filterEnabled = true;
                            s4.setSplitter(s5);

                            tags = new ArrayList();
                            tags.add("Past");
                            tags.add("Future");

                            TagSplitter s6 = new TagSplitter(tags);
                            s5.setSplitter(s6);

                            String identifier = "HierarchyLot" + i + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
//                                    String identifier = "single" + i + g1.name() + g2.name() + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
                            DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
                            settings.add(setting);
////                        }
                        }
//                            }
//                        }
                    }
                }
            }
        }
        System.out.println("settings.size() = " + settings.size());
        return settings;
    }

    public static List<DataSetSetting> aaAddSmallRating() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1289652004;
        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 20;
        int minValue = 4;
        boolean additive = true;
        int minimumNonZeroValues = 256;
        int i = 96;
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    public static List<DataSetSetting> aaAddSmallRating2() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1269993600;
        startTime = 1301529600;
        //5 years

        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 20;
        int minValue = 4;
        boolean additive = true;
        int minimumNonZeroValues = 250;
        int i = 90;
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

//        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        String identifier = "Cumulative5Year90MinutesRating.csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    public static List<DataSetSetting> aaRating() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1089652004;
        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 100;
        int minValue = 10;
        boolean additive = false;
        int minimumNonZeroValues = 10;
        int i = 10080;
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    public static List<DataSetSetting> aaRating2() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 922838400;// for 15 years

        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 100;
        int minValue = 25;
        boolean additive = false;
        int minimumNonZeroValues = 10;
        int i = 17520;//2 years
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

//        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        String identifier = "15Years2YearRating.csv";

        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    private static Collection<? extends DataSetSetting> addAARating() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1089652004;
        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 100;
        int minValue = 40;
        boolean additive = true;
        int minimumNonZeroValues = 40;
        int i = 672;
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    private static Collection<? extends DataSetSetting> addAARating2() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1112227200;//10 years
        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 100;
        int minValue = 40;
        boolean additive = true;
        int minimumNonZeroValues = 40;
//        int i = 720;//1 months
        int i = 1440;//2 months
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

//        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        String identifier = "Cumulative10Years2MonthRating.csv";

        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    private static Collection<? extends DataSetSetting> biMonthly18Rating() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1338963809;
        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 20;
        int minValue = 1;
        boolean additive = false;
        int minimumNonZeroValues = 1;
        int i = 1536;
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    private static Collection<? extends DataSetSetting> biMonthly18Rating2() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1333152000;//3 years
        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 20;
        int minValue = 1;
        boolean additive = false;
        int minimumNonZeroValues = 1;
        int i = 2160;//3 months
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

//        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        String identifier = "3Years2MonthRating.csv";

        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    private static Collection<? extends DataSetSetting> dialy9MonthsAARating() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1398916690;
        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 100;
        int minValue = 1;
        boolean additive = false;
        int minimumNonZeroValues = 1;
        int i = 24;
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    private static Collection<? extends DataSetSetting> dialy9MonthsAARating2() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
//        long startTime = 789652004;
        long endTime = 1427784002;
        long startTime = 1388448000;//3 months
        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.ACTION);
        genreList.add(Genre.ADVENTURE);

        int minTotalValue = 100;
        int minValue = 1;
        boolean additive = false;
        int minimumNonZeroValues = 1;
        int i = 24;//day
        int interval = 60 * 60 * i;

        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

//        String identifier = "single" + i + "ActionAdventure" + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        String identifier = "3Months1DayRating.csv";

        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);
        return settings;
    }

    private static Collection<? extends DataSetSetting> quarterAddRating() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
        long startTime = 1153318400;
        long endTime = 1427784002;

        int i = 168;
        long interval = 60 * 60 * i;
        int minimumNonZeroValues = 1;
        int minTotalValue = 640;
        int minValue = 16;
        boolean additive = true;

        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.CRIME);
        genreList.add(Genre.ADVENTURE);
        genreList.add(Genre.DRAMA);
        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        YearSplitter s2 = new YearSplitter(2010);
        s1.setSplitter(s2);

        List<String> tags = new ArrayList();
        tags.add("Ford");
        tags.add("Pitt");
        tags.add("Depp");
        tags.add("Hanks");
        tags.add("Stewart");
        tags.add("Cooper");
        tags.add("Grant");
        tags.add("Flynn");
////                            
        TagSplitter s3 = new TagSplitter(tags);
        s3.filterEnabled = true;
        s2.setSplitter(s3);

        List<String> titles = new ArrayList();
        titles.add("Act");
        titles.add("War");
        titles.add("Love");
        titles.add("Time");
        titles.add("Spirit");
        titles.add("Night");
        TitleSplitter s4 = new TitleSplitter(titles);
        s3.setSplitter(s4);
//                                    s4.filterEnabled = true;

        tags = new ArrayList();
        tags.add("Friend");
        tags.add("Enemy");

        TagSplitter s5 = new TagSplitter(tags);
        s5.label = "root//genSplit//yearSplit//titleSplit//split//split";
//                                    s5.filterEnabled = true;
        s4.setSplitter(s5);

        tags = new ArrayList();
        tags.add("Past");
        tags.add("Future");

        TagSplitter s6 = new TagSplitter(tags);
        s5.setSplitter(s6);

        String identifier = "HierarchyLot" + i + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);

        return settings;
    }

    private static Collection<? extends DataSetSetting> quarterAddRating2() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
        long startTime = 1143763200;
        long endTime = 1427784002;//9 years

        int i = 168;//1week
        long interval = 60 * 60 * i;
        int minimumNonZeroValues = 1;
        int minTotalValue = 640;
        int minValue = 16;
        boolean additive = true;

        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.CRIME);
        genreList.add(Genre.ADVENTURE);
        genreList.add(Genre.DRAMA);
        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        YearSplitter s2 = new YearSplitter(2010);
        s1.setSplitter(s2);

        List<String> tags = new ArrayList();
        tags.add("Ford");
        tags.add("Pitt");
        tags.add("Depp");
        tags.add("Hanks");
        tags.add("Stewart");
        tags.add("Cooper");
        tags.add("Grant");
        tags.add("Flynn");
////                            
        TagSplitter s3 = new TagSplitter(tags);
        s3.filterEnabled = true;
        s2.setSplitter(s3);

        List<String> titles = new ArrayList();
        titles.add("Act");
        titles.add("War");
        titles.add("Love");
        titles.add("Time");
        titles.add("Spirit");
        titles.add("Night");
        TitleSplitter s4 = new TitleSplitter(titles);
        s3.setSplitter(s4);
//                                    s4.filterEnabled = true;

        tags = new ArrayList();
        tags.add("Friend");
        tags.add("Enemy");

        TagSplitter s5 = new TagSplitter(tags);
        s5.label = "root//genSplit//yearSplit//titleSplit//split//split";
//                                    s5.filterEnabled = true;
        s4.setSplitter(s5);

        tags = new ArrayList();
        tags.add("Past");
        tags.add("Future");

        TagSplitter s6 = new TagSplitter(tags);
        s5.setSplitter(s6);

//        String identifier = "HierarchyLot" + i + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        String identifier = "HierarchyCumulative9Year1Week.csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);

        return settings;
    }

    private static Collection<? extends DataSetSetting> quarterRating() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
        long startTime = 789652004;
        long endTime = 1427784002;

        int i = 5376;
        long interval = 60 * 60 * i;
        int minimumNonZeroValues = 16;
        int minTotalValue = 10000;
        int minValue = 4000;
        boolean additive = false;

        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.CRIME);
        genreList.add(Genre.ADVENTURE);
        genreList.add(Genre.DRAMA);
        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        YearSplitter s2 = new YearSplitter(2010);
        s1.setSplitter(s2);

        List<String> tags = new ArrayList();
        tags.add("Ford");
        tags.add("Pitt");
        tags.add("Depp");
        tags.add("Hanks");
        tags.add("Stewart");
        tags.add("Cooper");
        tags.add("Grant");
        tags.add("Flynn");
////                            
        TagSplitter s3 = new TagSplitter(tags);
        s3.filterEnabled = true;
        s2.setSplitter(s3);

        List<String> titles = new ArrayList();
        titles.add("Act");
        titles.add("War");
        titles.add("Love");
        titles.add("Time");
        titles.add("Spirit");
        titles.add("Night");
        TitleSplitter s4 = new TitleSplitter(titles);
        s3.setSplitter(s4);
//                                    s4.filterEnabled = true;

        tags = new ArrayList();
        tags.add("Friend");
        tags.add("Enemy");

        TagSplitter s5 = new TagSplitter(tags);
        s5.label = "root//genSplit//yearSplit//titleSplit//split//split";
//                                    s5.filterEnabled = true;
        s4.setSplitter(s5);

        tags = new ArrayList();
        tags.add("Past");
        tags.add("Future");

        TagSplitter s6 = new TagSplitter(tags);
        s5.setSplitter(s6);

        String identifier = "HierarchyLot" + i + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);

        return settings;
    }

    private static Collection<? extends DataSetSetting> quarterRating2() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
        long startTime = 789652004;
        long endTime = 1427784002;

        int i = 5040;//1month
        long interval = 60 * 60 * i;
        int minimumNonZeroValues = 15;
        int minTotalValue = 10000;
        int minValue = 4000;
        boolean additive = false;

        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.CRIME);
        genreList.add(Genre.ADVENTURE);
        genreList.add(Genre.DRAMA);
        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        YearSplitter s2 = new YearSplitter(2010);
        s1.setSplitter(s2);

        List<String> tags = new ArrayList();
        tags.add("Ford");
        tags.add("Pitt");
        tags.add("Depp");
        tags.add("Hanks");
        tags.add("Stewart");
        tags.add("Cooper");
        tags.add("Grant");
        tags.add("Flynn");
////                            
        TagSplitter s3 = new TagSplitter(tags);
        s3.filterEnabled = true;
        s2.setSplitter(s3);

        List<String> titles = new ArrayList();
        titles.add("Act");
        titles.add("War");
        titles.add("Love");
        titles.add("Time");
        titles.add("Spirit");
        titles.add("Night");
        TitleSplitter s4 = new TitleSplitter(titles);
        s3.setSplitter(s4);
//                                    s4.filterEnabled = true;

        tags = new ArrayList();
        tags.add("Friend");
        tags.add("Enemy");

        TagSplitter s5 = new TagSplitter(tags);
        s5.label = "root//genSplit//yearSplit//titleSplit//split//split";
//                                    s5.filterEnabled = true;
        s4.setSplitter(s5);

        tags = new ArrayList();
        tags.add("Past");
        tags.add("Future");

        TagSplitter s6 = new TagSplitter(tags);
        s5.setSplitter(s6);

//        String identifier = "HierarchyLot" + i + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        String identifier = "Hierarchy22Year1Month.csv";

        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);

        return settings;
    }

    private static Collection<? extends DataSetSetting> WeeklyAddRating() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
        long startTime = 1153318400;
        long endTime = 1427784002;

        int i = 5040;
        long interval = 60 * 60 * i;
        int minimumNonZeroValues = 4;
        int minTotalValue = 10000;
        int minValue = 1000;
        boolean additive = true;

        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.CRIME);
        genreList.add(Genre.ADVENTURE);
        genreList.add(Genre.DRAMA);
        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        YearSplitter s2 = new YearSplitter(2010);
        s1.setSplitter(s2);

        List<String> tags = new ArrayList();
        tags.add("Ford");
        tags.add("Pitt");
        tags.add("Depp");
        tags.add("Hanks");
        tags.add("Stewart");
        tags.add("Cooper");
        tags.add("Grant");
        tags.add("Flynn");
////                            
        TagSplitter s3 = new TagSplitter(tags);
        s3.filterEnabled = true;
        s2.setSplitter(s3);

        List<String> titles = new ArrayList();
        titles.add("Act");
        titles.add("War");
        titles.add("Love");
        titles.add("Time");
        titles.add("Spirit");
        titles.add("Night");
        TitleSplitter s4 = new TitleSplitter(titles);
        s3.setSplitter(s4);
//                                    s4.filterEnabled = true;

        tags = new ArrayList();
        tags.add("Friend");
        tags.add("Enemy");

        TagSplitter s5 = new TagSplitter(tags);
        s5.label = "root//genSplit//yearSplit//titleSplit//split//split";
//                                    s5.filterEnabled = true;
        s4.setSplitter(s5);

        tags = new ArrayList();
        tags.add("Past");
        tags.add("Future");

        TagSplitter s6 = new TagSplitter(tags);
        s5.setSplitter(s6);

        String identifier = "HierarchyLot" + i + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);

        return settings;
    }

    private static Collection<? extends DataSetSetting> WeeklyAddRating2() {
        List<DataSetSetting> settings = new ArrayList();

        //complete period of time
        long startTime = 1143763200;//9 years
        long endTime = 1427784002;

        int i = 5040;//1 month
        long interval = 60 * 60 * i;
        int minimumNonZeroValues = 5;
        int minTotalValue = 10000;
        int minValue = 1000;
        boolean additive = true;

        ArrayList<Genre> genreList = new ArrayList();
        genreList.add(Genre.CRIME);
        genreList.add(Genre.ADVENTURE);
        genreList.add(Genre.DRAMA);
        GenreSplitter s1 = new GenreSplitter(genreList);
        s1.label = "root//split";
        s1.parentLabel = "root";
        s1.filterEnabled = true;

        YearSplitter s2 = new YearSplitter(2010);
        s1.setSplitter(s2);

        List<String> tags = new ArrayList();
        tags.add("Ford");
        tags.add("Pitt");
        tags.add("Depp");
        tags.add("Hanks");
        tags.add("Stewart");
        tags.add("Cooper");
        tags.add("Grant");
        tags.add("Flynn");
////                            
        TagSplitter s3 = new TagSplitter(tags);
        s3.filterEnabled = true;
        s2.setSplitter(s3);

        List<String> titles = new ArrayList();
        titles.add("Act");
        titles.add("War");
        titles.add("Love");
        titles.add("Time");
        titles.add("Spirit");
        titles.add("Night");
        TitleSplitter s4 = new TitleSplitter(titles);
        s3.setSplitter(s4);
//                                    s4.filterEnabled = true;

        tags = new ArrayList();
        tags.add("Friend");
        tags.add("Enemy");

        TagSplitter s5 = new TagSplitter(tags);
        s5.label = "root//genSplit//yearSplit//titleSplit//split//split";
//                                    s5.filterEnabled = true;
        s4.setSplitter(s5);

        tags = new ArrayList();
        tags.add("Past");
        tags.add("Future");

        TagSplitter s6 = new TagSplitter(tags);
        s5.setSplitter(s6);

//        String identifier = "HierarchyLot" + i + "Months" + "Start" + startTime + "End" + endTime + "NZ" + minimumNonZeroValues + "minTotal" + minTotalValue + "minVal" + minValue + "Additive" + additive + ".csv";
        String identifier = "HierarchyCumulative9Year1Month.csv";

        DataSetSetting setting = new DataSetSetting(s1, startTime, endTime, interval, additive, minimumNonZeroValues, identifier, minTotalValue, minValue);
        settings.add(setting);

        return settings;
    }
}
