/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviedatabase;

import filterDatabase.DataSetWriter;
import filterDatabase.GeneratedRating;
import moviedatabase.datastructures.MovieDataBase;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import moviedatabase.datastructures.Genre;
import moviedatabase.datastructures.Movie;
import moviedatabase.datastructures.Rating;
import moviedatabase.datastructures.Tag;
import moviedatabase.datastructures.User;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

/**
 *
 * @author msondag
 */
public class DataSetCreator {

    File inputFolder, outputFolder;

    //mapping from movieIds to originalMovies
    public HashMap<Integer, Movie> originalMovies = new HashMap();
    //mapping from userIds to originalUsers
    public HashMap<Integer, User> originalUsers = new HashMap();

    public ArrayList<Rating> originalRatings = new ArrayList();
    public ArrayList<Tag> originalTags = new ArrayList();

    private MovieDataBase originalDataBase;

    public static void main(String[] args) {
        // TODO code application logic here

        DataSetCreator dsc = new DataSetCreator(args);
        dsc.importData();
        System.out.println("data imported. start generation");
        List<DataSetSetting> settings = DataSetSetting.finalSettings2();
        for (DataSetSetting ds : settings) {
            System.out.println("start new processing");
            dsc.process(ds);
        }

    }

    public DataSetCreator(String[] args) {
        parseArguments(args);
    }

    public void importData() {
        try {
            //import the movie data from originalMovies.csv
            importMovies();
            //Import originalUsers and originalRatings from originalRatings.csv
            importUserRatings();
            //import the originalTags from tag.csv
            importTags();

            //Not being used at the moment, so considering space requirements we just clear them. Coupling is still present in movies.
            originalUsers = new HashMap();
            originalRatings = new ArrayList();
            originalTags = new ArrayList();

            originalDataBase = new MovieDataBase(originalMovies, originalUsers, originalRatings, originalTags, false);

            System.out.println("originalMovies.size() = " + originalMovies.size());
            System.out.println("originalUsers.size() " + originalUsers.size());
            System.out.println("originalRatings.size() = " + originalRatings.size());
            System.out.println("originalTags.size() = " + originalTags.size());
            long minTime = Long.MAX_VALUE;
            long maxTime = Long.MIN_VALUE;
            for (Rating r : originalRatings) {
                minTime = Math.min(minTime, r.timestamp);
                maxTime = Math.max(maxTime, r.timestamp);
            }
            System.out.println("intervalLength: " + (maxTime - minTime));
            System.out.println("minTime = " + minTime);
            System.out.println("maxTime = " + maxTime);
            System.out.println("check");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MovieDataBase.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MovieDataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void parseArguments(String args[]) {
        List<String> argumentList = Arrays.asList(args);
        ListIterator<String> it = argumentList.listIterator();
        while (it.hasNext()) {
            String arg = it.next();
            System.out.println("arg = " + arg);
            switch (arg) {
                case "-inputFolder":
                    inputFolder = new File(it.next());
                    System.out.println("inputFolder = " + inputFolder);
                    break;
                case "-outputFolder":
                    outputFolder = new File(it.next());
                    System.out.println("outputFolder = " + outputFolder);
                    break;
            }
        }
    }

    private void importMovies() throws IOException {
        String moviePath = inputFolder.getAbsolutePath() + "\\movies.csv";
        System.out.println("moviePath = " + moviePath);
        File movieFile = new File(moviePath);
        Reader reader = new FileReader(movieFile);
        CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);

        boolean header = true;
        for (CSVRecord record : parser) {
            if (header) {
                //skip header
                header = false;
                continue;
            }
            String movieId = record.get(0);
            String title = record.get(1);
            String genres = record.get(2);
            Movie m = new Movie(Integer.valueOf(movieId), title, Genre.convertStrings(genres));

            originalMovies.put(Integer.valueOf(movieId), m);
        }

    }

    private void importTags() throws IOException {
        String moviePath = inputFolder.getAbsolutePath() + "\\tags.csv";
        System.out.println("moviePath = " + moviePath);
        File movieFile = new File(moviePath);
        Reader reader = new FileReader(movieFile);
        CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);

        boolean header = true;
        for (CSVRecord record : parser) {
            if (header) {
                //skip header
                header = false;
                continue;
            }
            int userId = Integer.parseInt(record.get(0));
            int movieId = Integer.parseInt(record.get(1));
            String tag = record.get(2);
            long timestamp = Long.parseLong(record.get(3));

            Movie m = originalMovies.get(movieId);
            User u = originalUsers.get(userId);

            Tag t = new Tag(m, u, tag, timestamp);
            originalTags.add(t);
            m.addTag(t);
        }
    }

    private void importUserRatings() throws IOException {
        String moviePath = inputFolder.getAbsolutePath() + "\\ratings.csv";
        File movieFile = new File(moviePath);
        Reader reader = new FileReader(movieFile);

        CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);

        //    Map<Long, Integer> timeMap = new HashMap();
        boolean header = true;
        for (CSVRecord record : parser) {
            if (header) {
                //skip header
                header = false;
                continue;
            }
            int userId = Integer.parseInt(record.get(0));
            int movieId = Integer.parseInt(record.get(1));
            double rating = Double.parseDouble(record.get(2));
            long timestamp = Long.parseLong(record.get(3));

//            long time = (long) Math.floor(timestamp / 60 / 60 / 24);
//            if (!timeMap.containsKey(time)) {
//                timeMap.put(time, 0);
//            }
//            timeMap.put(time, timeMap.get(time) + 1);
            if (!originalUsers.containsKey(userId)) {
                User u = new User(userId);
                originalUsers.put(userId, u);
            }
            User u = originalUsers.get(userId);
            Movie m = originalMovies.get(movieId);

            Rating r = new Rating(m, u, rating, timestamp);
            originalRatings.add(r);
        }
//        for (long l : timeMap.keySet()) {
//            System.out.println("Day;" + l + ";" + "count" + timeMap.get(l));
//        }
    }

    private void process(DataSetSetting ds) {

        List<GeneratedRating> output = ds.root.getOutput(originalDataBase, ds);
        System.out.println("start writing");
        DataSetWriter dsw = new DataSetWriter();

        outputFolder.mkdir();
        String outputFileName = outputFolder + "\\" + ds.fileIdentifier;
        System.out.println("outputFileName = " + outputFileName);
        dsw.writeDataset(outputFileName, output);
    }

}
